//
//  PaperOnboarding.h
//  PaperOnboarding
//
//  Created by Alex K. on 31/05/16.
//  Copyright © 2016 Alex K. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for PaperOnboarding.
FOUNDATION_EXPORT double PaperOnboardingVersionNumber;

//! Project version string for PaperOnboarding.
FOUNDATION_EXPORT const unsigned char PaperOnboardingVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <PaperOnboarding/PublicHeader.h>


